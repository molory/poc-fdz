//
//  FidzupSdk.h
//  FidzupSdk
//
//  Created by Marc OLORY on 24/08/2017.
//  Copyright © 2017 Fidzup. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FidzupSdk.
FOUNDATION_EXPORT double FidzupSdkVersionNumber;

//! Project version string for FidzupSdk.
FOUNDATION_EXPORT const unsigned char FidzupSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FidzupSdk/PublicHeader.h>


